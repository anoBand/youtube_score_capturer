# YouTube Sheet Music Extractor

A web application that scans sheet music from YouTube videos and creates a PDF file.
